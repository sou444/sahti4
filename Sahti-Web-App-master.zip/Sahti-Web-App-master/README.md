# Sahti-Web-App
this is part 2 of sahti Project 
our chat bot live preview link : https://www.chatbot.com/preview/?widgetId=5e9afe0434de0f0007fc73b9 



because we face a probem to integrate him in our website you can try him fom the link 
